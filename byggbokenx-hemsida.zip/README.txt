BYGGBOKENX – HEMSIDA (första version)

Öppna index.html i valfri webbläsare för att förhandsgranska hemsidan.
För publicering: ladda upp filen till ett webbhotell eller statisk webbhost.

Viktigt:
- Detta är en statisk presentationshemsida, inte den inloggade kundplattformen.
- Kontaktlänken använder hej@byggbokenx.se som föreslagen adress. Skapa adressen eller byt den innan publicering.
- Domänens ägarskap/tillgänglighet är inte kontrollerad.
- Texten beskriver planerade funktioner; publicera inte som befintliga funktioner innan de är byggda.
